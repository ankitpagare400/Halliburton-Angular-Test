import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  public retPostData: Object | undefined;
  public retGetData: object | undefined;

  constructor(private http:HttpClient){}

  ngOnInit(){}

  public PostData(){

    let row = document.createElement('div');   
    row.className = 'row'; 
    row.innerHTML = ` 
    <br> 
    <input type="text">`; 
    
    //document.querySelector('.showInputField').appendChild(row); 

    const url="http://localhost:49528/api/home/";
    const retval= this.http.post(url,{ FstVarValue:'123',SndVarValue:'123'}).subscribe
    (data => {this.retPostData = data});
  }

  public GetData(){
    const url="http://localhost:49528/api/home/5";
    this.http.get(url).subscribe(data => this.retGetData = data)
  }
}
